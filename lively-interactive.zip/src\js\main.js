import { initFrameVideoPlayer } from './framePlayer.js';

document.addEventListener('DOMContentLoaded', () => {
    initFrameVideoPlayer();
});


